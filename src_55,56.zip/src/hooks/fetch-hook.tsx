// src/hooks/fetch-hook.ts
import { useRef, useCallback } from "react";

// URL 캐시를 저장할 Map
const urlMap = new Map<string, any>();

// 캐싱을 적용한 fetch 함수
const fetchByCache = async (url: string, signal?: AbortSignal) => {
  if (urlMap.has(url)) {
    return urlMap.get(url); // 캐시된 데이터 반환
  }
  const response = await fetch(url, { signal }); // AbortSignal을 fetch 옵션으로 전달
  const data = await response.json();
  urlMap.set(url, data); // 캐시에 저장
  return data;
};

// useFetch 커스텀 훅
export const useFetch = <T extends unknown>(url: string) => {
  const abortControllerRef = useRef<AbortController | null>(null);

  // 요청 취소 함수
  const abort = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      console.log("요청이 취소되었습니다.");
    }
  }, []);

  // 데이터 요청 함수
  const fetchData = useCallback(async (): Promise<T | undefined> => {
    // 기존 요청 취소
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // 새로운 AbortController 생성
    abortControllerRef.current = new AbortController();
    const { signal } = abortControllerRef.current;

    try {
      const data = await fetchByCache(url, signal); // 데이터 요청
      return data;
    } catch (error) {
      if (error.name === "AbortError") {
        console.log("요청이 취소되었습니다."); // 요청 취소 처리
      } else {
        throw new Error(`Error fetching data: ${error}`);
      }
    }
  }, [url]);

  return { abort, fetchData };
};
