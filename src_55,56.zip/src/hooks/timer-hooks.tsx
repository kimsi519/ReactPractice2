// src/hooks/useTimer.tsx
import { useEffect, useRef } from "react";

export const useTimeout = (callback: () => void, delay: number | null) => {
  const savedCallback = useRef<() => void>();

  // 콜백을 저장합니다.
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // 타이머를 설정합니다.
  useEffect(() => {
    if (delay === null) return;

    const timeoutId = setTimeout(() => {
      if (savedCallback.current) savedCallback.current();
    }, delay);

    // Cleanup을 처리합니다.
    return () => clearTimeout(timeoutId);
  }, [delay]);
};
