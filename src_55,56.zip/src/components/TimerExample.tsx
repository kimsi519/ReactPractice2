// src/components/TimerExample.tsx
import React from 'react';
import { useTimeout } from '../hooks/timer-hooks';

const TimerExample: React.FC = () => {
  // 1초 후 한 번만 실행되는 타임아웃 설정
  useTimeout(() => {
    console.log('Timeout: 실행되었습니다.');
  }, 1000);

  return (
    <div>
      <p>Time out</p>
    </div>
  );
};

export default TimerExample;
