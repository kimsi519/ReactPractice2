// src/components/My.tsx
import React, { useEffect, useState } from "react";
import { useFetch } from "../hooks/fetch-hook";

interface UserProps {
  userId: number;
}

interface User {
  id: number;
  name: string;
  username: string;
  email: string;
}

const MyComponent: React.FC<UserProps> = ({ userId }) => {
  const { abort, fetchData } = useFetch<User>(
    `https://jsonplaceholder.typicode.com/users/${userId}`
  );
  const [user, setUser] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const getUserData = async () => {
      setLoading(true);
      try {
        const data = await fetchData();
        if (data) {
          setUser(data);
        }
      } catch (error: any) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    getUserData();

    return () => {
      abort(); // 컴포넌트가 언마운트될 때 요청 취소
    };
  }, [userId]); // userId가 변경될 때만 데이터 요청

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  if (!user) return <p>No User Data</p>;

  return (
    <div>
      <h2>User Information</h2>
      <p>
        <strong>ID:</strong> {user.id}
      </p>
      <p>
        <strong>Name:</strong> {user.name}
      </p>
      <p>
        <strong>Username:</strong> {user.username}
      </p>
      <p>
        <strong>Email:</strong> {user.email}
      </p>
    </div>
  );
};

export default MyComponent;
