// src/App.tsx
import React, { useState } from "react";
import MyComponent from "./components/My";

function App() {
  const [userId, setUserId] = useState<number>(1); // 초기 userId는 1로 설정
  return (
    <div>
      <h1>Fetch User Information</h1>
      <div>
        <label htmlFor="userId">Enter User ID: </label>
        <input
          type="number"
          id="userId"
          value={userId}
          onChange={(e) => setUserId(parseInt(e.target.value, 10))}
        />
      </div>
      <MyComponent userId={userId} /> {/* userId를 MyComponent에 전달 */}
    </div>
  );
}

export default App;
